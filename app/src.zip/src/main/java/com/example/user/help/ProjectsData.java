package com.example.user.help;

/**
 * Created by user on 4/1/2018.
 */

public class ProjectsData {
    private String category;
    private String date;

    public ProjectsData() {

    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }
}

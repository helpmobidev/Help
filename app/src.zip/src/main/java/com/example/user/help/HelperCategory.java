package com.example.user.help;

/**
 * Created by USER on 3/27/2018.
 */

public class HelperCategory {
    String category;

    public HelperCategory()
    {}

    public HelperCategory(String category){
        this.category = category;
    }

    public String getCategory(){
        return category;
    }

    public void setCategory(String category){
        this.category = category;
    }
}
